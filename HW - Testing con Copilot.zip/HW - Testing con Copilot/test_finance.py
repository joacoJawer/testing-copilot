import pytest
from finance import calculate_compound_interest, calculate_annuity_payment, calculate_internal_rate_of_return
import math

def test_compound_interest_basic():
    assert math.isclose(calculate_compound_interest(1000, 0.05, 2), 1102.5)

def test_compound_interest_zero_rate():
    assert calculate_compound_interest(1000, 0, 10) == 1000

def test_compound_interest_zero_periods():
    assert calculate_compound_interest(1000, 0.05, 0) == 1000

def test_compound_interest_negative_principal():
    assert calculate_compound_interest(-1000, 0.05, 2) < 0

def test_compound_interest_large_periods():
    result = calculate_compound_interest(1000, 0.05, 100)
    assert result > 1000

def test_annuity_payment_basic():
    payment = calculate_annuity_payment(1000, 0.05, 10)
    assert payment > 0

def test_annuity_payment_zero_rate():
    assert math.isclose(calculate_annuity_payment(1000, 0, 10), 100)

def test_annuity_payment_one_period():
    assert math.isclose(calculate_annuity_payment(1000, 0.05, 1), 1050)

def test_annuity_payment_large_periods():
    payment = calculate_annuity_payment(1000, 0.05, 100)
    assert payment > 0

def test_annuity_payment_negative_principal():
    payment = calculate_annuity_payment(-1000, 0.05, 10)
    assert payment < 0

def test_internal_rate_of_return_basic():
    irr = calculate_internal_rate_of_return([-1000, 600, 600])
    assert 0 < irr < 1

def test_internal_rate_of_return_zero_flows():
    irr = calculate_internal_rate_of_return([0, 0, 0])
    assert math.isclose(irr, 0.1, abs_tol=1e-2)

def test_internal_rate_of_return_single_period():
    irr = calculate_internal_rate_of_return([-1000, 1100])
    assert 0 < irr < 1

def test_internal_rate_of_return_negative_returns():
    try:
        irr = calculate_internal_rate_of_return([-1000, -100, -100])
        # Si no hay excepción, debe ser un número finito
        assert math.isfinite(irr)
    except OverflowError:
        # Es aceptable que lance OverflowError en este caso extremo
        pass

def test_internal_rate_of_return_large_iterations():
    irr = calculate_internal_rate_of_return([-1000, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100], iterations=500)
    assert isinstance(irr, float)

def test_internal_rate_of_return_derivative_zero():
    # This should not crash, derivative will be zero if all cash flows are zero
    irr = calculate_internal_rate_of_return([0, 0, 0, 0])
    assert math.isclose(irr, 0.1, abs_tol=1e-2)
